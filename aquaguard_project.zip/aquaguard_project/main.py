#!/usr/bin/env python3
"""
main.py - AquaGuard demo runner (composition root).

Usage examples
--------------
  python main.py                         # full demo
  python main.py --section validation    # show how bad data is handled
  python main.py --section alerts --location SCH-101
  python main.py --section rankings
  python main.py --section whatif --reduction 25
  python main.py --json report.json      # export everything (incl. disclaimer) as JSON
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import List

from aquaguard.analytics import RankingEngine, WhatIfAnalyzer
from aquaguard.config import DISCLAIMER
from aquaguard.registry import AquaGuardRegistry, LocationNotFoundError
from aquaguard.reports import MonitoringReport
from aquaguard.sample_data import build_sample_registry

SECTIONS = ("validation", "alerts", "rankings", "whatif")
LINE = "=" * 100


def banner(title: str) -> None:
    print(f"\n{LINE}\n  {title}\n{LINE}")


def show_validation(registry: AquaGuardRegistry, reports: List[MonitoringReport]) -> None:
    banner("1. DATA VALIDATION - how incomplete / invalid / duplicate readings were handled")
    for rep in reports:
        dq = rep.data_quality()
        print(f"{rep.location.location_id:8} {rep.location.name:26} accepted={dq.accepted:<3} "
              f"partial={dq.partial:<2} rejected={dq.rejected}")
        for msg in dq.messages:
            print(f"           - {msg}")


def show_alerts(reports: List[MonitoringReport]) -> None:
    banner("2. LOCATION REPORTS - totals, averages, trends and explainable alerts")
    for rep in reports:
        print(rep.to_text(), end="\n\n")


def show_rankings(reports: List[MonitoringReport]) -> None:
    banner("3. RANKINGS")
    engine = RankingEngine(reports)
    for title, entries in (("Highest consumption per person", engine.by_consumption()),
                           ("Most alerts (CRITICAL=3, WARNING=2, INFO=1)", engine.by_alerts()),
                           ("Conservation priority (act first on #1)", engine.by_conservation_priority())):
        print(f"\n-- {title}")
        for e in entries:
            print(f"  #{e.rank} {e.name:26} {e.value:>8.1f} {e.unit:<14} {e.explanation}")


def show_whatif(reports: List[MonitoringReport], reduction: float) -> None:
    banner(f"4. WHAT-IF: every location cuts consumption by {reduction:g}%")
    analyzer = WhatIfAnalyzer()
    results = analyzer.compare(reports, reduction)
    print(f"{'Location':26} {'Now L/day':>10} {'Saved L/day':>12} {'Saved L/yr':>12} "
          f"{'L/person':>9} {'Benchmark':>9}  Meets?  Cut needed")
    for r in results:
        print(f"{r.name:26} {r.baseline_daily:>10,.0f} {r.saved_daily:>12,.0f} {r.saved_annual:>12,.0f} "
              f"{r.projected_lpcd:>9.0f} {r.benchmark_lpcd:>9.0f}  {'yes' if r.meets_benchmark else 'no ':6}  "
              f"{r.reduction_needed_for_benchmark_pct:.0f}%")
    total = sum(r.saved_annual for r in results)
    people = sum(r.people_basic_needs_per_year for r in results)
    print(f"\nCommunity total: {total:,.0f} litres/year saved - enough to cover the ~20 L/day basic needs "
          f"of about {people:,.0f} people for a year.")
    print("\nSweep for the top-ranked conservation target:")
    top_id = RankingEngine(reports).by_conservation_priority()[0].location_id
    rep = next(r for r in reports if r.location.location_id == top_id)
    for r in analyzer.sweep(rep, [5, 10, 20, 30]):
        print(f"  {r.name}: cut {r.reduction_pct:>4.0f}% -> {r.projected_lpcd:.0f} L/person/day, "
              f"saves {r.saved_annual:,.0f} L/yr, meets benchmark: {'yes' if r.meets_benchmark else 'no'}")
    print("  Tips:", " | ".join(rep.location.conservation_tips()))


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="AquaGuard - Community Water Quality & Usage Monitor")
    parser.add_argument("--section", choices=SECTIONS, help="show only one section (default: all)")
    parser.add_argument("--location", help="limit reports/what-if to a location id, e.g. SCH-101")
    parser.add_argument("--reduction", type=float, default=15.0, help="what-if reduction %% (default 15)")
    parser.add_argument("--json", metavar="PATH", help="also export all reports to a JSON file")
    args = parser.parse_args(argv)

    registry = build_sample_registry()
    reports = registry.build_reports()
    if args.location:
        try:
            registry.get_location(args.location)
        except LocationNotFoundError as exc:
            print(f"error: {exc}. Known ids: {', '.join(l.location_id for l in registry.locations)}")
            return 2
        reports = [r for r in reports if r.location.location_id == args.location]

    wanted = (args.section,) if args.section else SECTIONS
    if "validation" in wanted:
        show_validation(registry, reports)
    if "alerts" in wanted:
        show_alerts(reports)
    if "rankings" in wanted:
        show_rankings(reports)
    if "whatif" in wanted:
        try:
            show_whatif(reports, args.reduction)
        except ValueError as exc:
            print(f"error: {exc}")
            return 2

    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump({"reports": [r.to_dict() for r in reports], "disclaimer": DISCLAIMER}, fh, indent=2)
        print(f"\nExported JSON to {args.json}")

    print(f"\n{DISCLAIMER}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
