"""
analytics.py - Pure statistics helpers plus cross-location rankings and what-if analysis.

Layering note: this module is *below* reports.py (reports uses the helpers) and
only imports MonitoringReport for type hints, so there are no circular imports.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import Enum
from statistics import mean
from typing import TYPE_CHECKING, Dict, List, Optional, Sequence, Tuple

from .config import BASIC_NEED_LPCD, DEFAULT_WEIGHTS, ScoreWeights

if TYPE_CHECKING:  # pragma: no cover
    from .reports import MonitoringReport


# --------------------------------------------------------------------------- #
# Low-level helpers
# --------------------------------------------------------------------------- #
def pct_change(old: Optional[float], new: Optional[float]) -> Optional[float]:
    """Percentage change old -> new; None if it cannot be computed (missing or old == 0)."""
    if old is None or new is None or old == 0:
        return None
    return (new - old) / abs(old) * 100.0


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def find_runs(flags: Sequence[bool]) -> List[Tuple[int, int]]:
    """Inclusive (start, end) index pairs of consecutive True values."""
    runs: List[Tuple[int, int]] = []
    start: Optional[int] = None
    for i, flag in enumerate(flags):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(flags) - 1))
    return runs


class TrendDirection(Enum):
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    INSUFFICIENT_DATA = "insufficient data"


def linear_slope(values: Sequence[float]) -> float:
    """Least-squares slope of values against index 0..n-1 (stdlib only, no numpy)."""
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2
    y_mean = mean(values)
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den


def classify_trend(values: Sequence[float], tolerance_pct: float,
                   min_points: int) -> Tuple[TrendDirection, Optional[float]]:
    """
    Classify a series using the fitted line's total change across the series,
    expressed as a % of the series mean. Returns (direction, change_pct).
    """
    if len(values) < min_points:
        return TrendDirection.INSUFFICIENT_DATA, None
    avg = mean(values)
    if avg == 0:
        return TrendDirection.STABLE, 0.0
    change_pct = linear_slope(values) * (len(values) - 1) / avg * 100.0
    if change_pct > tolerance_pct:
        return TrendDirection.INCREASING, change_pct
    if change_pct < -tolerance_pct:
        return TrendDirection.DECREASING, change_pct
    return TrendDirection.STABLE, change_pct


def window_average(points: Sequence[Tuple[date, float]], end: date, window_days: int) -> Optional[float]:
    """Mean of values whose date lies in (end - window_days, end]; None if empty."""
    start = end - timedelta(days=window_days)
    vals = [v for d, v in points if start < d <= end]
    return mean(vals) if vals else None


# --------------------------------------------------------------------------- #
# Rankings
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class RankedEntry:
    rank: int
    location_id: str
    name: str
    category: str
    value: float
    unit: str
    explanation: str


class RankingEngine:
    """Builds three leaderboards from a list of MonitoringReports."""

    _CONSUMPTION_ALERT_TYPES = ("EXCESSIVE_CONSUMPTION", "CONSUMPTION_SPIKE")

    def __init__(self, reports: Sequence["MonitoringReport"],
                 weights: ScoreWeights = DEFAULT_WEIGHTS) -> None:
        self._reports = list(reports)
        self._weights = weights

    @staticmethod
    def _rank(rows: List[Tuple[float, "MonitoringReport", str]], unit: str,
              descending: bool = True) -> List[RankedEntry]:
        rows = sorted(rows, key=lambda r: r[0], reverse=descending)
        return [RankedEntry(i, rep.location.location_id, rep.location.name, rep.location.category,
                            round(val, 1), unit, why)
                for i, (val, rep, why) in enumerate(rows, start=1)]

    def by_consumption(self) -> List[RankedEntry]:
        """Highest average litres per person per day first (fair across site sizes)."""
        rows = []
        for rep in self._reports:
            cs = rep.consumption_summary()
            if cs.avg_per_capita_daily is None:
                continue
            rows.append((cs.avg_per_capita_daily, rep,
                         f"{cs.benchmark_ratio:.2f}x its {cs.benchmark_lpcd:g} L/person/day benchmark"))
        return self._rank(rows, "L/person/day")

    def by_alerts(self) -> List[RankedEntry]:
        """Most alert 'points' first (CRITICAL=3, WARNING=2, INFO=1)."""
        rows = []
        for rep in self._reports:
            alerts = rep.alerts()
            points = sum(int(a.severity) for a in alerts)
            crit = sum(1 for a in alerts if a.severity.name == "CRITICAL")
            warn = sum(1 for a in alerts if a.severity.name == "WARNING")
            rows.append((float(points), rep, f"{crit} critical, {warn} warning, "
                                              f"{len(alerts) - crit - warn} info"))
        return self._rank(rows, "alert points")

    def conservation_score(self, report: "MonitoringReport") -> Tuple[float, Dict[str, float]]:
        """
        Conservation-priority score 0-100 (higher = act sooner), explainable as:
            overuse (how far above benchmark) + consumption alerts + growth trend,
        multiplied by the location type's priority weight.
        """
        w = self._weights
        cs = report.consumption_summary()
        tr = report.trend()
        overuse = clamp((cs.benchmark_ratio or 0.0) / 2.0) * 100.0  # ratio 2.0x -> 100
        points = sum(int(a.severity) for a in report.alerts()
                     if a.alert_type.name in self._CONSUMPTION_ALERT_TYPES)
        alert_part = clamp(points / w.alert_points_cap) * 100.0
        growth = tr.window_change_pct if tr.window_change_pct is not None else (tr.overall_change_pct or 0.0)
        trend_part = clamp(max(growth, 0.0) / w.trend_cap_pct) * 100.0
        raw = w.overuse * overuse + w.consumption_alerts * alert_part + w.trend * trend_part
        score = min(100.0, raw * report.location.priority_weight)
        return score, {"overuse": round(overuse, 1), "consumption_alerts": round(alert_part, 1),
                       "trend": round(trend_part, 1), "type_weight": report.location.priority_weight}

    def by_conservation_priority(self) -> List[RankedEntry]:
        rows = []
        for rep in self._reports:
            score, parts = self.conservation_score(rep)
            why = (f"overuse {parts['overuse']:.0f}/100, consumption alerts {parts['consumption_alerts']:.0f}/100, "
                   f"growth {parts['trend']:.0f}/100, x{parts['type_weight']:g} type weight")
            rows.append((score, rep, why))
        return self._rank(rows, "priority score")


# --------------------------------------------------------------------------- #
# What-if analysis
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class WhatIfResult:
    location_id: str
    name: str
    reduction_pct: float
    baseline_daily: float
    projected_daily: float
    saved_daily: float
    saved_monthly: float
    saved_annual: float
    baseline_lpcd: float
    projected_lpcd: float
    benchmark_lpcd: float
    meets_benchmark: bool
    reduction_needed_for_benchmark_pct: float
    people_basic_needs_per_year: float   # people whose ~20 L/day basic need the annual saving could cover
    assumptions: str = field(default="Baseline = latest-window average litres/day (falls back to overall average).")


class WhatIfAnalyzer:
    """Estimates water saved if consumption falls by a configurable percentage."""

    @staticmethod
    def _baseline(report: "MonitoringReport") -> Optional[float]:
        tr = report.trend()
        return tr.current_avg if tr.current_avg is not None else report.consumption_summary().avg_daily_liters

    def simulate(self, report: "MonitoringReport", reduction_pct: float) -> Optional[WhatIfResult]:
        if not 0 <= reduction_pct <= 100:
            raise ValueError("reduction_pct must be between 0 and 100")
        baseline = self._baseline(report)
        if baseline is None:
            return None
        loc = report.location
        saved = baseline * reduction_pct / 100.0
        projected = baseline - saved
        base_lpcd = baseline / loc.occupants
        proj_lpcd = projected / loc.occupants
        needed = max(0.0, (1 - loc.benchmark_lpcd / base_lpcd) * 100.0) if base_lpcd > 0 else 0.0
        annual = saved * 365
        return WhatIfResult(
            location_id=loc.location_id, name=loc.name, reduction_pct=reduction_pct,
            baseline_daily=baseline, projected_daily=projected, saved_daily=saved,
            saved_monthly=saved * 30, saved_annual=annual, baseline_lpcd=base_lpcd,
            projected_lpcd=proj_lpcd, benchmark_lpcd=loc.benchmark_lpcd,
            meets_benchmark=proj_lpcd <= loc.benchmark_lpcd,
            reduction_needed_for_benchmark_pct=needed,
            people_basic_needs_per_year=annual / (BASIC_NEED_LPCD * 365))

    def compare(self, reports: Sequence["MonitoringReport"], reduction_pct: float) -> List[WhatIfResult]:
        """Run the same scenario for every location; biggest annual saving first."""
        results = [r for r in (self.simulate(rep, reduction_pct) for rep in reports) if r is not None]
        return sorted(results, key=lambda r: r.saved_annual, reverse=True)

    def sweep(self, report: "MonitoringReport", percentages: Sequence[float]) -> List[WhatIfResult]:
        """One location, several reduction levels (e.g. 5/10/20 %)."""
        return [r for r in (self.simulate(report, p) for p in percentages) if r is not None]
