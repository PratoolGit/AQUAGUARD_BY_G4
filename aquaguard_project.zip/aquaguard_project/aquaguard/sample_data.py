"""
sample_data.py - Deterministic demo data covering the edge cases judges will ask about.

Scenario map
------------
HH-001 Sharma   : healthy baseline + INCOMPLETE reading, INVALID (all-bad) reading,
                  DUPLICATE submission and ZERO-litre meter reading.
HH-002 Verma    : EXCESSIVE consumption - sudden jump that stays high (sustained) and keeps rising.
SCH-101 School  : HIGH TURBIDITY for 6 consecutive days (sustained) + one isolated pH excursion
                  (escalated because it is a school).
CC-201 Hall     : ERRATIC pH, isolated turbidity spike, and an unparseable-date record.
HH-003 Khan     : WEEKLY readings, steadily DECREASING usage (conservation exemplar).
"""
from __future__ import annotations

import random
from datetime import date, timedelta
from typing import Dict, List, Optional

from .config import DEFAULT_THRESHOLDS, Thresholds
from .models import CommunityCenter, Household, School
from .registry import AquaGuardRegistry

DAYS = 28


def _row(d: date, liters, ph, ntu, period: str = "daily", notes: str = "") -> Dict[str, object]:
    return {"date": d, "period": period, "consumption_liters": liters, "ph": ph,
            "turbidity_ntu": ntu, "notes": notes}


def build_sample_registry(end_date: Optional[date] = None, seed: int = 42,
                          thresholds: Thresholds = DEFAULT_THRESHOLDS) -> AquaGuardRegistry:
    rng = random.Random(seed)
    end = end_date or (date.today() - timedelta(days=1))
    days = [end - timedelta(days=DAYS - 1 - i) for i in range(DAYS)]
    reg = AquaGuardRegistry(thresholds=thresholds)

    # ---------------- HH-001: healthy household with data-entry problems ----------------
    reg.add_location(Household("HH-001", "Sharma Family", members=5, district="Purnia"))
    rows: List[Dict[str, object]] = []
    for i, d in enumerate(days):
        rows.append(_row(d, round(675 * rng.uniform(0.92, 1.08)), round(rng.uniform(7.1, 7.5), 2),
                         round(rng.uniform(0.2, 0.8), 2)))
    rows[4] = _row(days[4], None, 7.4, None, notes="INCOMPLETE: litres and turbidity not recorded")
    rows[8] = _row(days[8], -120, 15.2, "n/a", notes="INVALID: negative litres, impossible pH, text turbidity")
    rows[17] = _row(days[17], 0, 7.3, 0.5, notes="ZERO litres: meter fault?")
    reg.ingest_many("HH-001", rows)
    reg.ingest("HH-001", _row(days[12], 700, 7.2, 0.4, notes="DUPLICATE of an existing date"))

    # ---------------- HH-002: excessive & rising consumption ----------------
    reg.add_location(Household("HH-002", "Verma Family", members=4, district="Purnia"))
    rows = []
    for i, d in enumerate(days):
        liters = 540 * rng.uniform(0.96, 1.04) if i < 18 else 540 * (1.65 + 0.035 * (i - 18))
        rows.append(_row(d, round(liters), round(rng.uniform(7.0, 7.6), 2), round(rng.uniform(0.3, 0.9), 2)))
    reg.ingest_many("HH-002", rows)

    # ---------------- SCH-101: sustained high turbidity ----------------
    reg.add_location(School("SCH-101", "Govt Middle School", students=320, staff=20, district="Purnia"))
    bad_turbidity = [6.1, 7.4, 8.9, 11.2, 9.8, 7.6]
    rows = []
    for i, d in enumerate(days):
        ntu = bad_turbidity[i - 22] if i >= 22 else round(rng.uniform(0.5, 1.2), 2)
        ph = 8.7 if i == 8 else round(rng.uniform(7.3, 7.7), 2)
        rows.append(_row(d, round(15300 * rng.uniform(0.82, 0.98)), ph, ntu))
    reg.ingest_many("SCH-101", rows)

    # ---------------- CC-201: erratic pH ----------------
    reg.add_location(CommunityCenter("CC-201", "Ward 7 Community Hall", avg_daily_visitors=150, district="Purnia"))
    erratic_ph = [7.3, 6.2, 8.9, 7.1, 9.3, 7.2]
    rows = []
    for i, d in enumerate(days):
        ph = erratic_ph[i - 22] if i >= 22 else round(rng.uniform(7.0, 7.7), 2)
        ntu = 5.8 if i == 12 else round(rng.uniform(0.4, 1.4), 2)
        rows.append(_row(d, round(4500 * rng.uniform(0.9, 1.05)), ph, ntu))
    reg.ingest_many("CC-201", rows)
    reg.ingest("CC-201", {"date": "31-02-2026", "consumption_liters": 4300, "ph": 7.2,
                          "turbidity_ntu": 0.6, "notes": "INVALID DATE"})

    # ---------------- HH-003: weekly readings, conservation exemplar ----------------
    reg.add_location(Household("HH-003", "Khan Family", members=3, district="Purnia"))
    weekly = [2100, 2020, 1950, 1880]
    rows = [_row(days[i * 7], weekly[i], round(rng.uniform(7.1, 7.5), 2), round(rng.uniform(0.2, 0.5), 2),
                 period="weekly") for i in range(4)]
    reg.ingest_many("HH-003", rows)
    return reg
