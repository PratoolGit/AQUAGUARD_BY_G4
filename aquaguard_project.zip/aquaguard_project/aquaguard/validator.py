"""
validator.py - Gatekeeper that turns raw, messy input into trustworthy WaterReadings.

Handles: missing values, non-numeric text, NaN/inf, negative values, zero
consumption, out-of-range pH/turbidity, implausibly large consumption,
unparseable/future dates, unknown periods and duplicate (date, period) entries.

Outcome of validating one submission
------------------------------------
* ACCEPTED : every metric usable.
* PARTIAL  : at least one metric usable; bad/missing metrics are dropped (set to
             None) so they cannot corrupt averages and trends. Issues are logged.
* REJECTED : nothing usable (bad date, duplicate, or all metrics invalid).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Callable, List, Mapping, Optional, Tuple

from .config import DEFAULT_LIMITS, PhysicalLimits
from .models import Location, Period, WaterReading


class ValidationStatus(Enum):
    ACCEPTED = "accepted"
    PARTIAL = "partial"
    REJECTED = "rejected"


class IssueLevel(Enum):
    WARNING = "warning"  # value missing/dropped but record still usable
    ERROR = "error"      # value or record invalid


@dataclass(frozen=True)
class ValidationIssue:
    field: str
    level: IssueLevel
    message: str

    def __str__(self) -> str:
        return f"[{self.level.value.upper()}] {self.field}: {self.message}"


@dataclass
class ValidationResult:
    status: ValidationStatus
    reading: Optional[WaterReading]
    issues: List[ValidationIssue] = field(default_factory=list)
    raw_date: str = ""

    @property
    def accepted(self) -> bool:
        """True if a (possibly partial) reading was produced."""
        return self.reading is not None

    def messages(self) -> Tuple[str, ...]:
        return tuple(str(i) for i in self.issues)


class ReadingValidator:
    """Validates one raw submission (a mapping) against a target Location."""

    def __init__(self, limits: PhysicalLimits = DEFAULT_LIMITS,
                 today_fn: Callable[[], date] = date.today) -> None:
        self._limits = limits
        self._today_fn = today_fn

    # ------------------------------------------------------------------ #
    # public API
    # ------------------------------------------------------------------ #
    def validate(self, location: Location, raw: Mapping[str, object]) -> ValidationResult:
        """
        `raw` keys: date, period (optional, default daily), consumption_liters,
        ph, turbidity_ntu, notes (optional).
        """
        issues: List[ValidationIssue] = []
        raw_date = str(raw.get("date", ""))

        # ---- fatal checks: date, period, duplicate ----
        try:
            reading_date = self._parse_date(raw.get("date"))
        except ValueError as exc:
            issues.append(ValidationIssue("date", IssueLevel.ERROR, str(exc)))
            return ValidationResult(ValidationStatus.REJECTED, None, issues, raw_date)

        if reading_date > self._today_fn():
            issues.append(ValidationIssue("date", IssueLevel.ERROR, f"{reading_date} is in the future"))
            return ValidationResult(ValidationStatus.REJECTED, None, issues, raw_date)

        try:
            period = Period.parse(raw.get("period", Period.DAILY))
        except ValueError as exc:
            issues.append(ValidationIssue("period", IssueLevel.ERROR, str(exc)))
            return ValidationResult(ValidationStatus.REJECTED, None, issues, raw_date)

        if location.has_reading(reading_date, period):
            issues.append(ValidationIssue(
                "duplicate", IssueLevel.ERROR,
                f"a {period.value} reading for {reading_date} already exists (original kept)"))
            return ValidationResult(ValidationStatus.REJECTED, None, issues, raw_date)

        # ---- per-metric checks ----
        period_days = period.days(reading_date)
        consumption = self._check_consumption(raw.get("consumption_liters"), period_days, issues)
        ph = self._check_ph(raw.get("ph"), issues)
        turbidity = self._check_turbidity(raw.get("turbidity_ntu"), issues)

        if consumption is None and ph is None and turbidity is None:
            issues.append(ValidationIssue("record", IssueLevel.ERROR, "no usable metric in this reading"))
            return ValidationResult(ValidationStatus.REJECTED, None, issues, raw_date)

        reading = WaterReading(location.location_id, reading_date, period,
                               consumption, ph, turbidity, str(raw.get("notes", "")))
        status = ValidationStatus.ACCEPTED if reading.is_complete else ValidationStatus.PARTIAL
        return ValidationResult(status, reading, issues, raw_date)

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _parse_date(value: object) -> date:
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, str) and value.strip():
            try:
                return date.fromisoformat(value.strip())
            except ValueError:
                raise ValueError(f"cannot parse date {value!r} (use YYYY-MM-DD)") from None
        raise ValueError("date is missing")

    @staticmethod
    def _coerce(name: str, value: object, issues: List[ValidationIssue]) -> Optional[float]:
        """Turn input into a finite float, or record why it is unusable and return None."""
        if value is None or (isinstance(value, str) and value.strip() == ""):
            issues.append(ValidationIssue(name, IssueLevel.WARNING, "value is missing"))
            return None
        if isinstance(value, bool):
            issues.append(ValidationIssue(name, IssueLevel.ERROR, f"{value!r} is not a number"))
            return None
        try:
            number = float(value.strip() if isinstance(value, str) else value)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            issues.append(ValidationIssue(name, IssueLevel.ERROR, f"{value!r} is not numeric"))
            return None
        if not math.isfinite(number):
            issues.append(ValidationIssue(name, IssueLevel.ERROR, f"{value!r} is not a finite number"))
            return None
        return number

    def _check_consumption(self, value: object, period_days: int,
                           issues: List[ValidationIssue]) -> Optional[float]:
        number = self._coerce("consumption_liters", value, issues)
        if number is None:
            return None
        if number < 0:
            issues.append(ValidationIssue("consumption_liters", IssueLevel.ERROR,
                                          f"{number:g} L is negative (meter/entry error)"))
            return None
        if number == 0 and not self._limits.allow_zero_consumption:
            issues.append(ValidationIssue("consumption_liters", IssueLevel.WARNING,
                                          "0 L recorded - treated as missing (possible meter fault or vacancy)"))
            return None
        if number / period_days > self._limits.max_daily_liters:
            issues.append(ValidationIssue(
                "consumption_liters", IssueLevel.ERROR,
                f"{number:g} L over {period_days} day(s) exceeds the plausible maximum of "
                f"{self._limits.max_daily_liters:,.0f} L/day"))
            return None
        return number

    def _check_ph(self, value: object, issues: List[ValidationIssue]) -> Optional[float]:
        number = self._coerce("ph", value, issues)
        if number is None:
            return None
        if not self._limits.ph_min <= number <= self._limits.ph_max:
            issues.append(ValidationIssue(
                "ph", IssueLevel.ERROR,
                f"pH {number:g} is outside the physically possible {self._limits.ph_min:g}-"
                f"{self._limits.ph_max:g} scale (sensor/entry error)"))
            return None
        return number

    def _check_turbidity(self, value: object, issues: List[ValidationIssue]) -> Optional[float]:
        number = self._coerce("turbidity_ntu", value, issues)
        if number is None:
            return None
        if number < 0:
            issues.append(ValidationIssue("turbidity_ntu", IssueLevel.ERROR,
                                          f"{number:g} NTU is negative (sensor/entry error)"))
            return None
        if number > self._limits.turbidity_max_ntu:
            issues.append(ValidationIssue(
                "turbidity_ntu", IssueLevel.ERROR,
                f"{number:g} NTU exceeds the instrument ceiling of {self._limits.turbidity_max_ntu:g} NTU"))
            return None
        return number
