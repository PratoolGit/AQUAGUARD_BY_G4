"""
reports.py - MonitoringReport: aggregates one location's history into summaries,
trends and explainable alerts. Results are computed lazily and cached.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from statistics import mean
from typing import List, Optional, Tuple

from .alerts import Alert, AlertEngine
from .analytics import TrendDirection, classify_trend, pct_change, window_average
from .config import DEFAULT_THRESHOLDS, DISCLAIMER, Thresholds
from .models import Location, WaterReading


@dataclass(frozen=True)
class ConsumptionSummary:
    reading_count: int
    total_liters: float
    days_covered: int
    avg_daily_liters: Optional[float]
    avg_per_capita_daily: Optional[float]
    benchmark_lpcd: float
    benchmark_ratio: Optional[float]
    peak_daily_liters: Optional[float]
    peak_date: Optional[date]


@dataclass(frozen=True)
class QualitySummary:
    ph_count: int
    avg_ph: Optional[float]
    min_ph: Optional[float]
    max_ph: Optional[float]
    ph_abnormal_count: int
    turbidity_count: int
    avg_turbidity: Optional[float]
    max_turbidity: Optional[float]
    turbidity_abnormal_count: int


@dataclass(frozen=True)
class TrendSummary:
    direction: TrendDirection
    overall_change_pct: Optional[float]
    window_days: int
    current_avg: Optional[float]
    previous_avg: Optional[float]
    window_change_pct: Optional[float]
    period_changes: List[Tuple[date, float]] = field(default_factory=list)  # reading-to-reading % change


@dataclass(frozen=True)
class DataQualitySummary:
    accepted: int
    partial: int
    rejected: int
    messages: Tuple[str, ...]


class MonitoringReport:
    """Aggregation + analysis facade for a single Location."""

    def __init__(self, location: Location, thresholds: Thresholds = DEFAULT_THRESHOLDS,
                 engine: Optional[AlertEngine] = None, as_of: Optional[date] = None) -> None:
        self._location = location
        self._t = thresholds
        self._engine = engine or AlertEngine(thresholds)
        self._as_of = as_of
        self._alerts_cache: Optional[List[Alert]] = None

    @property
    def location(self) -> Location:
        return self._location

    @property
    def as_of(self) -> Optional[date]:
        return self._as_of or self._location.latest_date

    def _readings(self) -> List[WaterReading]:
        cutoff = self.as_of
        return [r for r in self._location.readings if cutoff is None or r.reading_date <= cutoff]

    def _use_points(self) -> List[Tuple[date, float]]:
        return [(r.reading_date, r.daily_equivalent_liters) for r in self._readings()
                if r.daily_equivalent_liters is not None]

    # ------------------------------------------------------------------ #
    def consumption_summary(self) -> ConsumptionSummary:
        used = [r for r in self._readings() if r.has_consumption]
        loc = self._location
        if not used:
            return ConsumptionSummary(0, 0.0, 0, None, None, loc.benchmark_lpcd, None, None, None)
        total = sum(r.consumption_liters for r in used)          # type: ignore[misc]
        days = sum(r.period_days for r in used)
        avg_daily = total / days
        per_capita = avg_daily / loc.occupants
        peak = max(used, key=lambda r: r.daily_equivalent_liters or 0.0)
        return ConsumptionSummary(len(used), total, days, avg_daily, per_capita, loc.benchmark_lpcd,
                                  per_capita / loc.benchmark_lpcd, peak.daily_equivalent_liters,
                                  peak.reading_date)

    def quality_summary(self) -> QualitySummary:
        t = self._t
        phs = [r.ph for r in self._readings() if r.ph is not None]
        ntus = [r.turbidity_ntu for r in self._readings() if r.turbidity_ntu is not None]
        return QualitySummary(
            len(phs), mean(phs) if phs else None, min(phs) if phs else None, max(phs) if phs else None,
            sum(1 for p in phs if p < t.ph_min or p > t.ph_max),
            len(ntus), mean(ntus) if ntus else None, max(ntus) if ntus else None,
            sum(1 for n in ntus if n > t.turbidity_max_ntu))

    def trend(self, window_days: Optional[int] = None) -> TrendSummary:
        """Overall direction (regression) + latest-window vs previous-window + reading-to-reading changes."""
        w = window_days or self._t.window_days
        points = self._use_points()
        values = [v for _, v in points]
        direction, overall = classify_trend(values, self._t.trend_tolerance_pct, self._t.trend_min_points)
        end = self.as_of
        cur = prev = None
        if end is not None:
            cur = window_average(points, end, w)
            prev = window_average(points, end - timedelta(days=w), w)
        changes = [(d1, c) for (_, v0), (d1, v1) in zip(points, points[1:])
                   if (c := pct_change(v0, v1)) is not None]
        return TrendSummary(direction, overall, w, cur, prev, pct_change(prev, cur), changes)

    def data_quality(self) -> DataQualitySummary:
        log = self._location.ingestion_log
        msgs = tuple(f"{rec.raw_date or '?'}: {m}" for rec in log if rec.status != "accepted"
                     for m in rec.messages)
        return DataQualitySummary(sum(r.status == "accepted" for r in log),
                                  sum(r.status == "partial" for r in log),
                                  sum(r.status == "rejected" for r in log), msgs)

    def alerts(self) -> List[Alert]:
        if self._alerts_cache is None:
            alerts = self._engine.evaluate(self._location, self._readings())
            dq = self.data_quality()
            extra = self._engine.data_quality_alert(self._location, dq.partial, dq.rejected)
            if extra:
                alerts.append(extra)
            self._alerts_cache = alerts
        return list(self._alerts_cache)

    # ------------------------------------------------------------------ #
    def to_text(self) -> str:
        loc, cs, qs, tr, dq = (self._location, self.consumption_summary(), self.quality_summary(),
                               self.trend(), self.data_quality())
        lines = [f"=== {loc.name} ({loc.location_id}) | {loc.category} | {loc.occupants} {loc.occupant_label} ==="]
        if cs.avg_daily_liters is None:
            lines.append("Consumption: no valid consumption readings.")
        else:
            lines.append(f"Consumption: total {cs.total_liters:,.0f} L over {cs.days_covered} days "
                         f"({cs.reading_count} readings) | avg {cs.avg_daily_liters:,.0f} L/day "
                         f"= {cs.avg_per_capita_daily:.0f} L/person/day "
                         f"({cs.benchmark_ratio:.2f}x benchmark {cs.benchmark_lpcd:g}) | "
                         f"peak {cs.peak_daily_liters:,.0f} L on {cs.peak_date}")
        if qs.ph_count or qs.turbidity_count:
            ph = f"pH avg {qs.avg_ph:.2f} (range {qs.min_ph:.1f}-{qs.max_ph:.1f}, {qs.ph_abnormal_count} abnormal)" \
                if qs.ph_count else "pH n/a"
            nt = f"turbidity avg {qs.avg_turbidity:.2f} NTU (max {qs.max_turbidity:.1f}, " \
                 f"{qs.turbidity_abnormal_count} abnormal)" if qs.turbidity_count else "turbidity n/a"
            lines.append(f"Quality    : {ph} | {nt}")
        wc = "n/a" if tr.window_change_pct is None else f"{tr.window_change_pct:+.1f}%"
        oc = "n/a" if tr.overall_change_pct is None else f"{tr.overall_change_pct:+.1f}%"
        lines.append(f"Trend      : {tr.direction.value} (fitted change {oc}); last {tr.window_days} days vs "
                     f"previous {tr.window_days} days: {wc}")
        lines.append(f"Data       : {dq.accepted} accepted, {dq.partial} partial, {dq.rejected} rejected")
        alerts = self.alerts()
        lines.append(f"Alerts     : {len(alerts)}" + ("" if alerts else " - none triggered"))
        for a in alerts:
            lines.append(a.render())
        return "\n".join(lines)

    def to_dict(self) -> dict:
        cs, qs, tr, dq = (self.consumption_summary(), self.quality_summary(), self.trend(), self.data_quality())
        return {
            "location": {"id": self._location.location_id, "name": self._location.name,
                         "category": self._location.category, "occupants": self._location.occupants},
            "consumption": {"total_liters": cs.total_liters, "days_covered": cs.days_covered,
                            "avg_daily_liters": cs.avg_daily_liters,
                            "avg_per_capita_daily": cs.avg_per_capita_daily,
                            "benchmark_ratio": cs.benchmark_ratio},
            "quality": {"avg_ph": qs.avg_ph, "avg_turbidity": qs.avg_turbidity,
                        "ph_abnormal": qs.ph_abnormal_count, "turbidity_abnormal": qs.turbidity_abnormal_count},
            "trend": {"direction": tr.direction.value, "overall_change_pct": tr.overall_change_pct,
                      "window_change_pct": tr.window_change_pct},
            "data_quality": {"accepted": dq.accepted, "partial": dq.partial, "rejected": dq.rejected},
            "alerts": [a.to_dict() for a in self.alerts()],
            "disclaimer": DISCLAIMER,
        }
