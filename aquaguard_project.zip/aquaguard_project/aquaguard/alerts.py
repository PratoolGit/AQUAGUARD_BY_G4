"""
alerts.py - Rule-based, explainable alerting.

Every alert says WHAT was observed, WHICH threshold it crossed, WHETHER it was an
isolated anomaly or a sustained pattern, and WHAT to do next - plus a disclaimer
that it is a monitoring indicator, not a lab certification.

Isolated vs sustained
---------------------
Readings are scanned in time order for each metric. Consecutive abnormal readings
form a "run". A run of >= `sustained_run` readings becomes ONE sustained alert
(severity escalated one level). Shorter runs become isolated alerts, one per reading.
Locations that serve vulnerable groups (e.g. schools) escalate isolated quality alerts.
"""
from __future__ import annotations

import textwrap
from dataclasses import dataclass
from datetime import date
from enum import Enum, IntEnum
from statistics import median
from typing import Callable, List, Optional, Sequence

from .analytics import find_runs
from .config import DEFAULT_THRESHOLDS, SHORT_DISCLAIMER, Thresholds
from .models import Location, WaterReading


class Severity(IntEnum):
    INFO = 1
    WARNING = 2
    CRITICAL = 3


class AlertType(Enum):
    PH_OUT_OF_RANGE = "pH out of range"
    PH_ERRATIC = "erratic pH"
    HIGH_TURBIDITY = "high turbidity"
    EXCESSIVE_CONSUMPTION = "excessive consumption"
    CONSUMPTION_SPIKE = "consumption spike"
    DATA_QUALITY = "data quality"


class Pattern(Enum):
    ISOLATED = "isolated"
    SUSTAINED = "sustained"
    N_A = "n/a"


@dataclass(frozen=True)
class Alert:
    location_id: str
    location_name: str
    alert_type: AlertType
    severity: Severity
    pattern: Pattern
    start_date: date
    end_date: date
    observed: Optional[float]
    threshold: str
    explanation: str
    recommendation: str
    disclaimer: str = SHORT_DISCLAIMER

    def render(self, width: int = 100) -> str:
        span = str(self.start_date) if self.start_date == self.end_date else f"{self.start_date} -> {self.end_date}"
        head = (f"[{self.severity.name}] {self.alert_type.value.upper()} | {self.pattern.value} | "
                f"{self.location_name} | {span}")
        body = [textwrap.fill(f"Why: {self.explanation}", width, initial_indent="    ", subsequent_indent="         "),
                textwrap.fill(f"Action: {self.recommendation}", width, initial_indent="    ", subsequent_indent="            "),
                f"    ({self.disclaimer})"]
        return "\n".join([head] + body)

    def to_dict(self) -> dict:
        return {"location_id": self.location_id, "location": self.location_name,
                "type": self.alert_type.name, "severity": self.severity.name,
                "pattern": self.pattern.value, "start": self.start_date.isoformat(),
                "end": self.end_date.isoformat(), "observed": self.observed,
                "threshold": self.threshold, "explanation": self.explanation,
                "recommendation": self.recommendation, "disclaimer": self.disclaimer}


@dataclass(frozen=True)
class Finding:
    """Result of applying one rule to one reading."""

    severity: Severity
    observed: float
    rule: str          # human-readable threshold that was crossed
    magnitude: float   # how far beyond the threshold (used to pick the run's peak)


Evaluator = Callable[[WaterReading, int, Sequence[WaterReading]], Optional[Finding]]

_RECOMMENDATIONS = {
    AlertType.PH_OUT_OF_RANGE: "Re-test with a calibrated meter or kit; if confirmed, check source/treatment, "
                               "avoid drinking until verified, and consult a local water-quality lab.",
    AlertType.PH_ERRATIC: "Check probe calibration and sampling method; look for intermittent dosing, mixing "
                          "or contamination at the source.",
    AlertType.HIGH_TURBIDITY: "Inspect and clean storage tanks and filters, check pipe breaks or recent "
                              "construction, and boil/filter water until a lab test confirms it is clear.",
    AlertType.EXCESSIVE_CONSUMPTION: "Inspect for leaks (taps, cisterns, overhead-tank overflow, underground "
                                     "pipes) and review usage habits.",
    AlertType.CONSUMPTION_SPIKE: "Compare with events (guests, repairs, filling a tank); if none, check for a "
                                 "new leak or a stuck float valve.",
    AlertType.DATA_QUALITY: "Re-enter or re-measure the affected readings so trends stay reliable.",
}


class AlertEngine:
    """Applies configurable threshold rules to a location's readings."""

    def __init__(self, thresholds: Thresholds = DEFAULT_THRESHOLDS) -> None:
        self._t = thresholds

    # ------------------------------------------------------------------ #
    # public
    # ------------------------------------------------------------------ #
    def evaluate(self, location: Location, readings: Sequence[WaterReading]) -> List[Alert]:
        ph_series = [r for r in readings if r.has_ph]
        ntu_series = [r for r in readings if r.has_turbidity]
        use_series = [r for r in readings if r.has_consumption]

        alerts: List[Alert] = []
        alerts += self._pattern_alerts(location, ph_series, self._rule_ph, AlertType.PH_OUT_OF_RANGE,
                                       "pH", "", quality=True)
        alerts += self._erratic_ph(location, ph_series)
        alerts += self._pattern_alerts(location, ntu_series, self._rule_turbidity, AlertType.HIGH_TURBIDITY,
                                       "Turbidity", " NTU", quality=True)
        alerts += self._pattern_alerts(location, use_series, self._make_excess_rule(location),
                                       AlertType.EXCESSIVE_CONSUMPTION, "Per-person consumption",
                                       " L/person/day", quality=False)
        alerts += self._pattern_alerts(location, use_series, self._rule_spike, AlertType.CONSUMPTION_SPIKE,
                                       "Consumption", " L/day", quality=False)
        alerts.sort(key=lambda a: (-int(a.severity), a.start_date))
        return alerts

    def data_quality_alert(self, location: Location, partial: int, rejected: int) -> Optional[Alert]:
        """INFO alert summarising incomplete/invalid submissions."""
        if partial == 0 and rejected == 0:
            return None
        day = location.latest_date or date.today()
        return Alert(location.location_id, location.name, AlertType.DATA_QUALITY, Severity.INFO,
                     Pattern.N_A, day, day, None, "complete, valid readings",
                     f"{partial} reading(s) were incomplete (unusable fields dropped) and {rejected} were "
                     f"rejected (invalid or duplicate). Averages and trends use only the valid values.",
                     _RECOMMENDATIONS[AlertType.DATA_QUALITY])

    # ------------------------------------------------------------------ #
    # rules (each returns a Finding or None for one reading)
    # ------------------------------------------------------------------ #
    def _rule_ph(self, r: WaterReading, _i: int, _s: Sequence[WaterReading]) -> Optional[Finding]:
        t, ph = self._t, r.ph
        assert ph is not None
        if ph < t.ph_min or ph > t.ph_max:
            critical = ph < t.ph_critical_min or ph > t.ph_critical_max
            dist = (t.ph_min - ph) if ph < t.ph_min else (ph - t.ph_max)
            return Finding(Severity.CRITICAL if critical else Severity.WARNING, ph,
                           f"acceptable pH range {t.ph_min:g}-{t.ph_max:g} "
                           f"(critical beyond {t.ph_critical_min:g}-{t.ph_critical_max:g})", dist)
        return None

    def _rule_turbidity(self, r: WaterReading, _i: int, _s: Sequence[WaterReading]) -> Optional[Finding]:
        t, ntu = self._t, r.turbidity_ntu
        assert ntu is not None
        if ntu > t.turbidity_max_ntu:
            sev = Severity.CRITICAL if ntu > t.turbidity_critical_ntu else Severity.WARNING
            return Finding(sev, ntu, f"limit {t.turbidity_max_ntu:g} NTU "
                                     f"(critical above {t.turbidity_critical_ntu:g} NTU)", ntu - t.turbidity_max_ntu)
        return None

    def _make_excess_rule(self, location: Location) -> Evaluator:
        t = self._t

        def rule(r: WaterReading, _i: int, _s: Sequence[WaterReading]) -> Optional[Finding]:
            daily = r.daily_equivalent_liters
            assert daily is not None
            per_capita = daily / location.occupants
            ratio = per_capita / location.benchmark_lpcd
            if ratio >= t.excessive_warn_factor:
                sev = Severity.CRITICAL if ratio >= t.excessive_critical_factor else Severity.WARNING
                return Finding(sev, per_capita,
                               f"{t.excessive_warn_factor:g}x the {location.benchmark_lpcd:g} L/person/day "
                               f"benchmark for a {location.category.lower()} (critical at "
                               f"{t.excessive_critical_factor:g}x)", ratio)
            return None

        return rule

    def _rule_spike(self, r: WaterReading, i: int, series: Sequence[WaterReading]) -> Optional[Finding]:
        t = self._t
        history = [x.daily_equivalent_liters for x in series[max(0, i - 14):i]]
        history = [h for h in history if h is not None]
        daily = r.daily_equivalent_liters
        if daily is None or len(history) < t.spike_min_history:
            return None
        baseline = median(history)
        if baseline <= 0:
            return None
        rise = (daily - baseline) / baseline * 100.0
        if rise > t.spike_pct:
            return Finding(Severity.WARNING, daily,
                           f"{t.spike_pct:g}% above the recent median of {baseline:,.0f} L/day", rise)
        return None

    # ------------------------------------------------------------------ #
    # generic isolated-vs-sustained machinery
    # ------------------------------------------------------------------ #
    def _pattern_alerts(self, location: Location, series: Sequence[WaterReading], rule: Evaluator,
                        alert_type: AlertType, label: str, unit: str, quality: bool) -> List[Alert]:
        findings = [rule(r, i, series) for i, r in enumerate(series)]
        alerts: List[Alert] = []
        for start, end in find_runs([f is not None for f in findings]):
            run = [f for f in findings[start:end + 1] if f is not None]
            length = end - start + 1
            peak = max(run, key=lambda f: f.magnitude)
            base_sev = max(f.severity for f in run)
            if length >= self._t.sustained_run:
                pattern = Pattern.SUSTAINED
                severity = Severity(min(Severity.CRITICAL, base_sev + 1))
                d0, d1 = series[start].reading_date, series[end].reading_date
                why = (f"{label} crossed the threshold ({peak.rule}) in {length} consecutive readings ({d0} to {d1}); "
                       f"peak {peak.observed:,.1f}{unit}. A persistent pattern points to a systemic cause "
                       f"rather than a one-off glitch, so severity was raised one level.")
                alerts.append(self._make(location, alert_type, severity, pattern, d0, d1, peak, why))
                continue
            for idx in range(start, end + 1):
                f = findings[idx]
                assert f is not None
                severity = f.severity
                note = ""
                if quality and location.escalate_quality_alerts and severity < Severity.CRITICAL:
                    severity = Severity(severity + 1)
                    note = f" Escalated one level because this {location.category.lower()} serves vulnerable users."
                d = series[idx].reading_date
                persistence = ("neighbouring readings were within limits" if length == 1 else
                               f"the abnormal run lasted only {length} readings (< {self._t.sustained_run} needed "
                               f"to count as sustained)")
                why = (f"{label} of {f.observed:,.1f}{unit} on {d} crossed the threshold ({f.rule}). It is classed as an "
                       f"isolated anomaly because {persistence}; possible causes include a sampling error, "
                       f"sensor drift or a one-off event.{note}")
                alerts.append(self._make(location, alert_type, severity, Pattern.ISOLATED, d, d, f, why))
        return alerts

    def _erratic_ph(self, location: Location, ph_series: Sequence[WaterReading]) -> List[Alert]:
        t = self._t
        swings = [(a, b) for a, b in zip(ph_series, ph_series[1:])
                  if abs(b.ph - a.ph) > t.ph_swing]  # type: ignore[operator]
        if len(swings) < t.ph_erratic_swings:
            return []
        biggest = max(abs(b.ph - a.ph) for a, b in swings)  # type: ignore[operator]
        severity = Severity.WARNING
        note = ""
        if location.escalate_quality_alerts:
            severity, note = Severity.CRITICAL, " Escalated because this site serves vulnerable users."
        rule = f"pH swing limit of {t.ph_swing:g} between consecutive readings (>= {t.ph_erratic_swings} swings)"
        f = Finding(severity, biggest, rule, biggest)
        why = (f"pH jumped by more than {t.ph_swing:g} unit between consecutive readings {len(swings)} times "
               f"(largest swing {biggest:.1f}). Stable water rarely behaves this way, so this may signal "
               f"intermittent contamination, unstable dosing or a faulty probe.{note}")
        return [self._make(location, AlertType.PH_ERRATIC, severity, Pattern.SUSTAINED,
                           swings[0][0].reading_date, swings[-1][1].reading_date, f, why)]

    @staticmethod
    def _make(location: Location, alert_type: AlertType, severity: Severity, pattern: Pattern,
              d0: date, d1: date, finding: Finding, why: str) -> Alert:
        return Alert(location.location_id, location.name, alert_type, severity, pattern, d0, d1,
                     round(finding.observed, 2), finding.rule, why, _RECOMMENDATIONS[alert_type])
