"""
config.py - Central, configurable settings for AquaGuard.

Everything a judge, NGO or municipality might want to tune lives here, so no
"magic numbers" are buried in the analysis code.

Three groups of settings:
  * PhysicalLimits - what is *physically possible* (used to reject bad data).
  * Thresholds     - what is *acceptable* (used to raise monitoring alerts).
  * ScoreWeights   - how conservation-priority scores are composed.

Important distinction (a good talking point for the demo):
  INVALID  = impossible value (pH 15, negative litres)  -> data is rejected.
  ABNORMAL = possible but outside the acceptable range  -> data is kept + alerted.
"""
from __future__ import annotations

from dataclasses import dataclass

DISCLAIMER = (
    "DISCLAIMER: AquaGuard flags are automated MONITORING INDICATORS based on "
    "configurable thresholds and user-supplied readings. They are NOT laboratory "
    "certifications and must not be used as proof that water is safe or unsafe. "
    "Confirm concerns with calibrated testing or an accredited laboratory."
)

SHORT_DISCLAIMER = "Monitoring indicator only - not a lab certification."


@dataclass(frozen=True)
class PhysicalLimits:
    """Hard limits used by the validator to decide whether a value is *possible*."""

    ph_min: float = 0.0
    ph_max: float = 14.0
    turbidity_max_ntu: float = 1000.0
    max_daily_liters: float = 1_000_000.0  # per-day equivalent plausibility cap
    allow_zero_consumption: bool = False   # zero litres usually means a meter fault


@dataclass(frozen=True)
class Thresholds:
    """
    Configurable alert thresholds.

    Defaults follow commonly cited drinking-water guideline ranges
    (e.g. pH 6.5-8.5, turbidity <= 5 NTU as in BIS IS 10500 / WHO guidance).
    Always verify against the standards that apply in your jurisdiction.
    """

    # --- pH ---
    ph_min: float = 6.5
    ph_max: float = 8.5
    ph_critical_min: float = 6.0   # beyond this -> CRITICAL
    ph_critical_max: float = 9.0
    ph_swing: float = 1.5          # reading-to-reading jump regarded as a "swing"
    ph_erratic_swings: int = 2     # number of swings that makes pH "erratic"

    # --- turbidity (NTU) ---
    turbidity_max_ntu: float = 5.0
    turbidity_critical_ntu: float = 10.0

    # --- consumption ---
    excessive_warn_factor: float = 1.5      # x per-capita benchmark -> WARNING
    excessive_critical_factor: float = 2.0  # x per-capita benchmark -> CRITICAL
    spike_pct: float = 50.0                 # % above recent baseline -> spike
    spike_min_history: int = 3              # readings needed to form a baseline

    # --- pattern detection / trends ---
    sustained_run: int = 3          # consecutive abnormal readings = "sustained"
    trend_tolerance_pct: float = 5.0
    trend_min_points: int = 4
    window_days: int = 7

    def __post_init__(self) -> None:
        if not self.ph_critical_min <= self.ph_min < self.ph_max <= self.ph_critical_max:
            raise ValueError("pH thresholds must satisfy critical_min <= min < max <= critical_max")
        if not 0 < self.turbidity_max_ntu <= self.turbidity_critical_ntu:
            raise ValueError("turbidity thresholds must satisfy 0 < max <= critical")
        if not 1.0 <= self.excessive_warn_factor <= self.excessive_critical_factor:
            raise ValueError("excessive-consumption factors must satisfy 1 <= warn <= critical")
        if self.sustained_run < 2:
            raise ValueError("sustained_run must be at least 2")
        if self.window_days < 1:
            raise ValueError("window_days must be >= 1")


@dataclass(frozen=True)
class ScoreWeights:
    """Weights for the conservation-priority score (should sum to 1.0)."""

    overuse: float = 0.6             # how far above the per-capita benchmark
    consumption_alerts: float = 0.2  # excessive/spike alert severity points
    trend: float = 0.2               # is consumption growing?
    alert_points_cap: float = 10.0   # alert points that map to 100% of that component
    trend_cap_pct: float = 50.0      # growth % that maps to 100% of the trend component


DEFAULT_LIMITS = PhysicalLimits()
DEFAULT_THRESHOLDS = Thresholds()
DEFAULT_WEIGHTS = ScoreWeights()

# Used by the what-if module to make savings tangible: an approximate basic-access
# water need (drinking, cooking, hygiene) of ~20 litres per person per day.
BASIC_NEED_LPCD = 20.0
