"""
models.py - Domain classes for AquaGuard.

OOP concepts demonstrated here
------------------------------
* Abstraction     : `Location` is an abstract base class (cannot be instantiated).
* Inheritance     : `Household`, `School`, `CommunityCenter` extend `Location`.
* Polymorphism    : each subclass overrides benchmark, priority weight, wording
                    and conservation tips; callers just use the `Location` API.
* Encapsulation   : `WaterReading` is effectively immutable (read-only
                    properties, __slots__) and refuses to be built in an
                    impossible state; `Location` hides its reading store.

This module deliberately knows nothing about thresholds, alerts or reports.
"""
from __future__ import annotations

import calendar
import math
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Dict, Iterable, List, Optional, Tuple


# --------------------------------------------------------------------------- #
# Enumerations & small value objects
# --------------------------------------------------------------------------- #
class Period(Enum):
    """The time span a single reading covers."""

    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

    def days(self, start: date) -> int:
        """Number of days covered by a reading of this period starting on `start`."""
        if self is Period.DAILY:
            return 1
        if self is Period.WEEKLY:
            return 7
        return calendar.monthrange(start.year, start.month)[1]

    @classmethod
    def parse(cls, value: object) -> "Period":
        """Accept a Period or a case-insensitive string; raise ValueError otherwise."""
        if isinstance(value, cls):
            return value
        if isinstance(value, str):
            try:
                return cls(value.strip().lower())
            except ValueError:
                pass
        raise ValueError(f"Unknown period {value!r}; expected one of daily/weekly/monthly")


class DuplicateReadingError(ValueError):
    """Raised when a location already has a reading for the same date and period."""


@dataclass(frozen=True)
class IngestionRecord:
    """Audit-trail entry describing what happened to one submitted reading."""

    status: str                 # "accepted" | "partial" | "rejected"
    raw_date: str
    messages: Tuple[str, ...] = ()


# --------------------------------------------------------------------------- #
# WaterReading
# --------------------------------------------------------------------------- #
def _is_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


class WaterReading:
    """
    One observation for one location: consumption (litres), pH and turbidity (NTU).

    Any of the three metrics may be None (an *incomplete* reading), but at least
    one must be present. The constructor enforces only absolute physical truths
    (non-negative litres, pH within 0-14, non-negative turbidity). Softer,
    configurable plausibility rules live in `validator.ReadingValidator`.
    """

    __slots__ = ("_location_id", "_date", "_period", "_consumption", "_ph", "_turbidity", "_notes")

    def __init__(
        self,
        location_id: str,
        reading_date: date,
        period: Period = Period.DAILY,
        consumption_liters: Optional[float] = None,
        ph: Optional[float] = None,
        turbidity_ntu: Optional[float] = None,
        notes: str = "",
    ) -> None:
        if not isinstance(reading_date, date):
            raise ValueError("reading_date must be a datetime.date")
        if not isinstance(period, Period):
            raise ValueError("period must be a Period")
        for name, value in (("consumption_liters", consumption_liters), ("ph", ph),
                            ("turbidity_ntu", turbidity_ntu)):
            if value is not None and not _is_number(value):
                raise ValueError(f"{name} must be a finite number or None, got {value!r}")
        if consumption_liters is not None and consumption_liters < 0:
            raise ValueError("consumption_liters cannot be negative")
        if ph is not None and not 0 <= ph <= 14:
            raise ValueError("ph must be within 0-14")
        if turbidity_ntu is not None and turbidity_ntu < 0:
            raise ValueError("turbidity_ntu cannot be negative")
        if consumption_liters is None and ph is None and turbidity_ntu is None:
            raise ValueError("a reading needs at least one metric")

        self._location_id = location_id
        self._date = reading_date
        self._period = period
        self._consumption = None if consumption_liters is None else float(consumption_liters)
        self._ph = None if ph is None else float(ph)
        self._turbidity = None if turbidity_ntu is None else float(turbidity_ntu)
        self._notes = notes

    # --- read-only properties (encapsulation) ---
    @property
    def location_id(self) -> str:
        return self._location_id

    @property
    def reading_date(self) -> date:
        return self._date

    @property
    def period(self) -> Period:
        return self._period

    @property
    def consumption_liters(self) -> Optional[float]:
        return self._consumption

    @property
    def ph(self) -> Optional[float]:
        return self._ph

    @property
    def turbidity_ntu(self) -> Optional[float]:
        return self._turbidity

    @property
    def notes(self) -> str:
        return self._notes

    # --- derived values ---
    @property
    def key(self) -> Tuple[date, Period]:
        """Identity of a reading within one location (used for duplicate detection)."""
        return (self._date, self._period)

    @property
    def period_days(self) -> int:
        return self._period.days(self._date)

    @property
    def daily_equivalent_liters(self) -> Optional[float]:
        """Consumption normalised to litres/day so daily, weekly and monthly data compare fairly."""
        if self._consumption is None:
            return None
        return self._consumption / self.period_days

    @property
    def has_consumption(self) -> bool:
        return self._consumption is not None

    @property
    def has_ph(self) -> bool:
        return self._ph is not None

    @property
    def has_turbidity(self) -> bool:
        return self._turbidity is not None

    @property
    def is_complete(self) -> bool:
        return self.has_consumption and self.has_ph and self.has_turbidity

    def to_dict(self) -> dict:
        return {
            "location_id": self._location_id,
            "date": self._date.isoformat(),
            "period": self._period.value,
            "consumption_liters": self._consumption,
            "ph": self._ph,
            "turbidity_ntu": self._turbidity,
            "notes": self._notes,
        }

    def __repr__(self) -> str:
        return (f"WaterReading({self._location_id}, {self._date}, {self._period.value}, "
                f"L={self._consumption}, pH={self._ph}, NTU={self._turbidity})")


# --------------------------------------------------------------------------- #
# Location hierarchy
# --------------------------------------------------------------------------- #
class Location(ABC):
    """
    Abstract monitored site. Owns its reading history and ingestion audit log.

    Subclasses supply the *policy* differences (benchmarks, priority weight,
    wording, tips); this base class supplies the shared *mechanics*.
    """

    def __init__(self, location_id: str, name: str, occupants: int, district: str = "") -> None:
        if not location_id or not name:
            raise ValueError("location_id and name are required")
        if not isinstance(occupants, int) or isinstance(occupants, bool) or occupants <= 0:
            raise ValueError("occupants must be a positive integer")
        self._location_id = location_id
        self._name = name
        self._occupants = occupants
        self._district = district
        self._readings: Dict[Tuple[date, Period], WaterReading] = {}
        self._ingestion_log: List[IngestionRecord] = []

    # --- identity ---
    @property
    def location_id(self) -> str:
        return self._location_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def occupants(self) -> int:
        return self._occupants

    @property
    def district(self) -> str:
        return self._district

    # --- polymorphic policy (overridden by subclasses) ---
    @property
    @abstractmethod
    def category(self) -> str:
        """Human-readable category, e.g. 'Household'."""

    @property
    @abstractmethod
    def benchmark_lpcd(self) -> float:
        """Reference litres per person per day for this kind of site."""

    @property
    @abstractmethod
    def occupant_label(self) -> str:
        """What 'occupants' means here: residents / students & staff / daily visitors."""

    @property
    def priority_weight(self) -> float:
        """Multiplier applied to conservation-priority scores."""
        return 1.0

    @property
    def escalate_quality_alerts(self) -> bool:
        """True where vulnerable groups (e.g. children) are served: quality alerts escalate."""
        return False

    @abstractmethod
    def conservation_tips(self) -> List[str]:
        """Practical, site-specific water-saving suggestions."""

    # --- shared behaviour ---
    @property
    def expected_daily_liters(self) -> float:
        return self.benchmark_lpcd * self._occupants

    def has_reading(self, reading_date: date, period: Period) -> bool:
        return (reading_date, period) in self._readings

    def add_reading(self, reading: WaterReading) -> None:
        """Store an already-validated reading; duplicates are refused."""
        if reading.location_id != self._location_id:
            raise ValueError("reading belongs to a different location")
        if reading.key in self._readings:
            raise DuplicateReadingError(
                f"{self._location_id} already has a {reading.period.value} reading for {reading.reading_date}")
        self._readings[reading.key] = reading

    @property
    def readings(self) -> List[WaterReading]:
        """Chronological copy of the history (callers cannot mutate our store)."""
        return sorted(self._readings.values(), key=lambda r: (r.reading_date, r.period.value))

    @property
    def latest_date(self) -> Optional[date]:
        return max((r.reading_date for r in self._readings.values()), default=None)

    def log_ingestion(self, record: IngestionRecord) -> None:
        self._ingestion_log.append(record)

    @property
    def ingestion_log(self) -> List[IngestionRecord]:
        return list(self._ingestion_log)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._location_id!r}, {self._name!r}, occupants={self._occupants})"


class Household(Location):
    """A family home. Benchmark: ~135 L/person/day (commonly used urban planning figure)."""

    def __init__(self, location_id: str, name: str, members: int, district: str = "") -> None:
        super().__init__(location_id, name, members, district)

    @property
    def category(self) -> str:
        return "Household"

    @property
    def benchmark_lpcd(self) -> float:
        return 135.0

    @property
    def occupant_label(self) -> str:
        return "residents"

    def conservation_tips(self) -> List[str]:
        return ["Fix dripping taps and running toilets (a leak can waste 100+ L/day).",
                "Fit low-flow aerators and use a bucket instead of a hose.",
                "Re-use RO reject / washing water for floors and plants."]


class School(Location):
    """A school. Serves children, so quality alerts are escalated; benchmark ~45 L/person/day."""

    def __init__(self, location_id: str, name: str, students: int, staff: int = 0,
                 district: str = "") -> None:
        if students <= 0 or staff < 0:
            raise ValueError("students must be > 0 and staff >= 0")
        super().__init__(location_id, name, students + staff, district)
        self._students = students
        self._staff = staff

    @property
    def students(self) -> int:
        return self._students

    @property
    def staff(self) -> int:
        return self._staff

    @property
    def category(self) -> str:
        return "School"

    @property
    def benchmark_lpcd(self) -> float:
        return 45.0

    @property
    def occupant_label(self) -> str:
        return "students & staff"

    @property
    def priority_weight(self) -> float:
        return 1.2  # schools are demonstration sites: savings have educational spill-over

    @property
    def escalate_quality_alerts(self) -> bool:
        return True

    def conservation_tips(self) -> List[str]:
        return ["Run a student 'water monitor' club to check taps and urinal flush timers daily.",
                "Install auto-closing (push) taps in washrooms.",
                "Harvest rainwater for gardens and toilet flushing."]


class CommunityCenter(Location):
    """A shared hall / health post. Occupants = average daily visitors; benchmark ~30 L/visitor/day."""

    def __init__(self, location_id: str, name: str, avg_daily_visitors: int,
                 district: str = "") -> None:
        super().__init__(location_id, name, avg_daily_visitors, district)

    @property
    def category(self) -> str:
        return "Community Center"

    @property
    def benchmark_lpcd(self) -> float:
        return 30.0

    @property
    def occupant_label(self) -> str:
        return "daily visitors"

    @property
    def priority_weight(self) -> float:
        return 1.1  # shared infrastructure is used by many households

    def conservation_tips(self) -> List[str]:
        return ["Add a closing-time tap and tank-overflow check to the caretaker's routine.",
                "Display water-saving posters; the centre influences the whole neighbourhood.",
                "Use sensor/push taps and dual-flush cisterns in shared toilets."]


def total_occupants(locations: Iterable[Location]) -> int:
    """Convenience helper used in summaries."""
    return sum(loc.occupants for loc in locations)
