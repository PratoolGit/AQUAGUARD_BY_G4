"""
registry.py - Service layer: owns all locations and is the single entry point for
ingesting readings (validate -> store -> audit-log). Keeps models free of I/O logic.
"""
from __future__ import annotations

from datetime import date
from typing import Dict, Iterable, List, Mapping, Optional

from .config import DEFAULT_THRESHOLDS, Thresholds
from .models import IngestionRecord, Location
from .reports import MonitoringReport
from .validator import ReadingValidator, ValidationResult


class LocationNotFoundError(KeyError):
    """Raised when a reading is submitted for an unknown location id."""


class AquaGuardRegistry:
    def __init__(self, validator: Optional[ReadingValidator] = None,
                 thresholds: Thresholds = DEFAULT_THRESHOLDS) -> None:
        self._validator = validator or ReadingValidator()
        self._thresholds = thresholds
        self._locations: Dict[str, Location] = {}

    @property
    def thresholds(self) -> Thresholds:
        return self._thresholds

    @property
    def locations(self) -> List[Location]:
        return list(self._locations.values())

    def add_location(self, location: Location) -> Location:
        if location.location_id in self._locations:
            raise ValueError(f"location id {location.location_id!r} already registered")
        self._locations[location.location_id] = location
        return location

    def get_location(self, location_id: str) -> Location:
        try:
            return self._locations[location_id]
        except KeyError:
            raise LocationNotFoundError(f"unknown location {location_id!r}") from None

    def ingest(self, location_id: str, raw: Mapping[str, object]) -> ValidationResult:
        """Validate one raw reading; store it if usable; always write an audit record."""
        location = self.get_location(location_id)
        result = self._validator.validate(location, raw)
        if result.reading is not None:
            location.add_reading(result.reading)
        location.log_ingestion(IngestionRecord(result.status.value, result.raw_date, result.messages()))
        return result

    def ingest_many(self, location_id: str, rows: Iterable[Mapping[str, object]]) -> List[ValidationResult]:
        return [self.ingest(location_id, row) for row in rows]

    def build_reports(self, as_of: Optional[date] = None) -> List[MonitoringReport]:
        return [MonitoringReport(loc, self._thresholds, as_of=as_of) for loc in self._locations.values()]
