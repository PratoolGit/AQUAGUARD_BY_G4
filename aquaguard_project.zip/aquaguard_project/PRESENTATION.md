# AquaGuard - Presentation Blueprint (5-7 minutes)

1. **Problem (45s)** - Communities lack affordable, continuous visibility of water use and quality. Leaks waste
   water silently; quality problems are noticed late; data from manual logs is messy and incomplete.
2. **Solution (45s)** - AquaGuard turns simple readings (litres, pH, turbidity) into trustworthy, explainable
   monitoring: validated data -> trends -> alerts that say *why* -> rankings -> what-if savings.
3. **Architecture (60s)** - Layers: `models` (domain) -> `validator` (data gate) -> `registry` (service) ->
   `alerts` + `reports` + `analytics` (insight) -> `main` (UI). Config-driven thresholds; stdlib only.
4. **OOP concepts (90s)** - Abstraction: abstract `Location`. Inheritance + polymorphism: Household/School/
   CommunityCenter differ in benchmark, priority weight, alert escalation, tips. Encapsulation: immutable
   `WaterReading` that cannot hold impossible values; `Location` hides its store. Composition: `MonitoringReport`
   owns an `AlertEngine`; dependency injection of validator/thresholds. Single responsibility per module.
5. **Live demo (2 min)** - (a) `--section validation`: bad data handled. (b) School turbidity: sustained vs
   isolated, read the "Why" text. (c) `--section rankings`. (d) `--section whatif --reduction 25`.
6. **Responsible design (30s)** - Invalid (impossible) vs abnormal (possible but risky) data; explainable rules,
   no black box; explicit disclaimer: monitoring indicator, not a lab certification.
7. **Impact & roadmap (30s)** - Litres saved per year, people-equivalents (SDG 6 & 12). Next: CSV/SMS/IoT input,
   dashboard, per-district maps, lab-test integration, multilingual alerts.

**Likely judge questions:** Why not ML? (explainability + tiny data; rules are auditable.) How do you avoid false
alarms? (isolated vs sustained logic, validation gate.) How scalable? (registry can sit behind an API/DB.)
