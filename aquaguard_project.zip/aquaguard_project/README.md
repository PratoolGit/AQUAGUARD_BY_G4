# AquaGuard - Community Water Quality & Usage Monitor
SDG 6 (Clean Water & Sanitation) | SDG 12 (Responsible Consumption & Production)

Pure-Python 3.9+ prototype, **zero third-party dependencies**.

## Structure
```
aquaguard_project/
├── main.py                  # CLI demo runner (composition root)
├── aquaguard/
│   ├── config.py            # Thresholds, PhysicalLimits, ScoreWeights, DISCLAIMER
│   ├── models.py            # Period, WaterReading, Location (ABC) + Household/School/CommunityCenter
│   ├── validator.py         # ReadingValidator -> ValidationResult (accepted / partial / rejected)
│   ├── alerts.py            # AlertEngine, Alert, Severity - isolated vs sustained, explainable
│   ├── reports.py           # MonitoringReport: totals, averages, trends, alerts
│   ├── analytics.py         # stats helpers, RankingEngine, WhatIfAnalyzer
│   ├── registry.py          # AquaGuardRegistry: ingest = validate -> store -> audit log
│   └── sample_data.py       # deterministic demo data with edge cases
└── tests/test_aquaguard.py  # 29 unit tests (unittest)
```
Dependency direction (no cycles): `config <- models <- validator <- registry`, `analytics <- alerts <- reports`.

## Run
```bash
python main.py                                  # full demo
python main.py --section validation             # incomplete / invalid / duplicate handling
python main.py --section alerts                 # per-location reports + explainable alerts
python main.py --section alerts --location SCH-101
python main.py --section rankings               # consumption / alerts / conservation priority
python main.py --section whatif --reduction 25  # savings if usage drops 25 %
python main.py --json report.json               # machine-readable export
python -m unittest discover -v                  # run tests
```

## Demo scenarios (what to look for)
| Location | Scenario | Expected output |
|---|---|---|
| HH-001 Sharma | incomplete, all-invalid, duplicate, zero-litre readings | 25 accepted / 2 partial / 2 rejected + INFO data-quality alert |
| HH-002 Verma | consumption jumps ~65% and keeps rising | CRITICAL sustained EXCESSIVE_CONSUMPTION + CONSUMPTION_SPIKE; #1 conservation priority |
| SCH-101 School | 6 days of turbidity 6-11 NTU, one pH of 8.7 | CRITICAL sustained HIGH_TURBIDITY; isolated pH alert escalated (school) |
| CC-201 Hall | pH swinging 6.2 / 8.9 / 7.1 / 9.3, one 5.8 NTU spike, bad date | PH_ERRATIC, isolated pH + turbidity alerts, 1 rejected record |
| HH-003 Khan | weekly readings, falling usage | no alerts, DECREASING trend, lowest priority |

## Extending
* New location type: subclass `Location`, implement `category`, `benchmark_lpcd`, `occupant_label`, `conservation_tips`.
* New rule: write an evaluator returning `Finding | None` and pass it to `AlertEngine._pattern_alerts`.
* Real data: call `registry.ingest(location_id, {...})` from a CSV reader, API, or IoT gateway.
* Tune everything in `config.py` (or pass a custom `Thresholds(...)` to the registry).

## Disclaimer
Alerts are monitoring indicators based on configurable thresholds and user-supplied data. They are **not**
laboratory certifications. Default thresholds follow commonly cited guideline ranges (pH 6.5-8.5, turbidity
<= 5 NTU); verify against your local standards.
