"""Stdlib-only tests: run with `python -m unittest discover -v` from the project root."""
import unittest
from datetime import date, timedelta

from aquaguard.alerts import AlertType, Pattern, Severity
from aquaguard.analytics import RankingEngine, TrendDirection, WhatIfAnalyzer, find_runs, pct_change
from aquaguard.config import Thresholds
from aquaguard.models import (CommunityCenter, Household, Location, Period, School, WaterReading)
from aquaguard.registry import AquaGuardRegistry, LocationNotFoundError
from aquaguard.reports import MonitoringReport
from aquaguard.sample_data import build_sample_registry
from aquaguard.validator import ValidationStatus

END = date(2026, 6, 30)


def day(i, total=10):
    return END - timedelta(days=total - 1 - i)


def make_registry(loc=None):
    reg = AquaGuardRegistry()
    reg.add_location(loc or Household("H1", "Test Home", members=4))
    return reg


def feed(reg, lid, series):
    """series: list of (liters, ph, ntu) tuples, one per consecutive day."""
    for i, (l, p, n) in enumerate(series):
        reg.ingest(lid, {"date": day(i, len(series)), "consumption_liters": l, "ph": p, "turbidity_ntu": n})


class TestModels(unittest.TestCase):
    def test_location_is_abstract(self):
        with self.assertRaises(TypeError):
            Location("x", "x", 1)  # type: ignore[abstract]

    def test_polymorphism(self):
        locs = [Household("a", "A", 4), School("b", "B", 100, 10), CommunityCenter("c", "C", 50)]
        self.assertEqual([l.benchmark_lpcd for l in locs], [135.0, 45.0, 30.0])
        self.assertEqual(locs[1].occupants, 110)
        self.assertTrue(locs[1].escalate_quality_alerts)
        self.assertFalse(locs[0].escalate_quality_alerts)
        self.assertTrue(all(l.conservation_tips() for l in locs))

    def test_reading_rejects_impossible_state(self):
        for kwargs in ({"consumption_liters": -1}, {"ph": 15}, {"turbidity_ntu": -0.1},
                       {"ph": float("nan")}, {}):
            with self.assertRaises(ValueError):
                WaterReading("a", END, Period.DAILY, **kwargs)

    def test_reading_is_read_only_and_normalises(self):
        r = WaterReading("a", date(2026, 6, 1), Period.WEEKLY, consumption_liters=700, ph=7)
        with self.assertRaises(AttributeError):
            r.ph = 9  # type: ignore[misc]
        self.assertEqual(r.daily_equivalent_liters, 100)
        m = WaterReading("a", date(2026, 2, 1), Period.MONTHLY, consumption_liters=2800)
        self.assertEqual(m.period_days, 28)


class TestValidator(unittest.TestCase):
    def setUp(self):
        self.reg = make_registry()

    def ingest(self, **raw):
        raw.setdefault("date", END)
        return self.reg.ingest("H1", raw)

    def test_valid(self):
        self.assertEqual(self.ingest(consumption_liters=500, ph=7, turbidity_ntu=1).status, ValidationStatus.ACCEPTED)

    def test_missing_gives_partial(self):
        res = self.ingest(consumption_liters=None, ph=7.2, turbidity_ntu="")
        self.assertEqual(res.status, ValidationStatus.PARTIAL)
        self.assertIsNone(res.reading.consumption_liters)

    def test_negative_zero_and_out_of_range(self):
        res = self.ingest(consumption_liters=-5, ph=7.0, turbidity_ntu=0.5)
        self.assertEqual(res.status, ValidationStatus.PARTIAL)
        res = self.ingest(date=END - timedelta(days=1), consumption_liters=0, ph=7.0, turbidity_ntu=0.5)
        self.assertIsNone(res.reading.consumption_liters)
        res = self.ingest(date=END - timedelta(days=2), consumption_liters=100, ph=15, turbidity_ntu=-1)
        self.assertIsNone(res.reading.ph)
        self.assertIsNone(res.reading.turbidity_ntu)

    def test_all_bad_is_rejected(self):
        res = self.ingest(consumption_liters="abc", ph=99, turbidity_ntu=None)
        self.assertEqual(res.status, ValidationStatus.REJECTED)
        self.assertEqual(len(self.reg.get_location("H1").readings), 0)

    def test_duplicate_rejected_original_kept(self):
        self.ingest(consumption_liters=500, ph=7, turbidity_ntu=1)
        res = self.ingest(consumption_liters=999, ph=7, turbidity_ntu=1)
        self.assertEqual(res.status, ValidationStatus.REJECTED)
        self.assertEqual(self.reg.get_location("H1").readings[0].consumption_liters, 500)

    def test_bad_dates_and_period(self):
        self.assertEqual(self.ingest(date="nope", consumption_liters=1).status, ValidationStatus.REJECTED)
        self.assertEqual(self.ingest(date=date(2999, 1, 1), consumption_liters=1).status, ValidationStatus.REJECTED)
        self.assertEqual(self.ingest(period="hourly", consumption_liters=1).status, ValidationStatus.REJECTED)

    def test_nan_and_bool_inputs(self):
        res = self.ingest(consumption_liters=float("nan"), ph=True, turbidity_ntu=0.5)
        self.assertIsNone(res.reading.consumption_liters)
        self.assertIsNone(res.reading.ph)

    def test_unknown_location(self):
        with self.assertRaises(LocationNotFoundError):
            self.reg.ingest("nope", {"date": END})


class TestAlerts(unittest.TestCase):
    def alerts_for(self, loc, series, kind):
        reg = make_registry(loc)
        feed(reg, loc.location_id, series)
        rep = MonitoringReport(loc)
        return [a for a in rep.alerts() if a.alert_type is kind]

    def test_isolated_ph(self):
        series = [(540, 7.2, 0.5)] * 4 + [(540, 9.4, 0.5)] + [(540, 7.2, 0.5)] * 4
        alerts = self.alerts_for(Household("H1", "H", 4), series, AlertType.PH_OUT_OF_RANGE)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].pattern, Pattern.ISOLATED)
        self.assertIn("monitoring indicator", alerts[0].render().lower())
        self.assertIn("threshold", alerts[0].explanation)

    def test_sustained_turbidity_escalates(self):
        series = [(540, 7.2, 0.5)] * 5 + [(540, 7.2, 6.0)] * 4
        alerts = self.alerts_for(Household("H1", "H", 4), series, AlertType.HIGH_TURBIDITY)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].pattern, Pattern.SUSTAINED)
        self.assertEqual(alerts[0].severity, Severity.CRITICAL)  # WARNING level, escalated by persistence

    def test_school_escalates_isolated_quality_alert(self):
        series = [(15000, 7.5, 0.5)] * 4 + [(15000, 7.5, 6.0)] + [(15000, 7.5, 0.5)] * 4
        home = self.alerts_for(Household("H1", "H", 340), series, AlertType.HIGH_TURBIDITY)[0]
        school = self.alerts_for(School("S1", "S", 300, 40), series, AlertType.HIGH_TURBIDITY)[0]
        self.assertEqual(home.severity, Severity.WARNING)
        self.assertEqual(school.severity, Severity.CRITICAL)

    def test_excessive_consumption_uses_per_capita_benchmark(self):
        series = [(540, 7.2, 0.5)] * 3 + [(1200, 7.2, 0.5)] * 3  # 4 people: 300 L/p/d = 2.2x
        alerts = self.alerts_for(Household("H1", "H", 4), series, AlertType.EXCESSIVE_CONSUMPTION)
        self.assertEqual(alerts[0].pattern, Pattern.SUSTAINED)  # 3 consecutive excessive days
        self.assertEqual(alerts[0].severity, Severity.CRITICAL)

    def test_normal_data_has_no_alerts(self):
        reg = make_registry()
        feed(reg, "H1", [(540, 7.2, 0.5)] * 10)
        self.assertEqual(MonitoringReport(reg.get_location("H1")).alerts(), [])

    def test_erratic_ph(self):
        series = [(540, p, 0.5) for p in (7.0, 8.4, 6.8, 8.3, 7.0, 7.1)]
        self.assertEqual(len(self.alerts_for(Household("H1", "H", 4), series, AlertType.PH_ERRATIC)), 1)

    def test_custom_thresholds_change_outcome(self):
        loc = Household("H1", "H", 4)
        reg = make_registry(loc)
        feed(reg, "H1", [(540, 8.0, 0.5)] * 6)
        strict = MonitoringReport(loc, Thresholds(ph_max=7.5, ph_critical_max=9.0))
        self.assertTrue(any(a.alert_type is AlertType.PH_OUT_OF_RANGE for a in strict.alerts()))
        self.assertEqual(MonitoringReport(loc).alerts(), [])

    def test_threshold_validation(self):
        with self.assertRaises(ValueError):
            Thresholds(ph_min=9, ph_max=7)


class TestAnalytics(unittest.TestCase):
    def test_helpers(self):
        self.assertEqual(find_runs([False, True, True, False, True]), [(1, 2), (4, 4)])
        self.assertAlmostEqual(pct_change(100, 150), 50.0)
        self.assertIsNone(pct_change(0, 5))
        self.assertIsNone(pct_change(None, 5))

    def test_trend_and_period_over_period(self):
        reg = make_registry()
        feed(reg, "H1", [(500 + 30 * i, 7.2, 0.5) for i in range(14)])
        rep = MonitoringReport(reg.get_location("H1"))
        tr = rep.trend()
        self.assertEqual(tr.direction, TrendDirection.INCREASING)
        self.assertGreater(tr.window_change_pct, 0)
        self.assertEqual(len(tr.period_changes), 13)
        cs = rep.consumption_summary()
        self.assertEqual(cs.total_liters, sum(500 + 30 * i for i in range(14)))
        self.assertEqual(cs.days_covered, 14)

    def test_insufficient_data(self):
        reg = make_registry()
        feed(reg, "H1", [(500, 7.2, 0.5)] * 2)
        self.assertEqual(MonitoringReport(reg.get_location("H1")).trend().direction,
                         TrendDirection.INSUFFICIENT_DATA)

    def test_mixed_periods_are_normalised(self):
        reg = make_registry()
        reg.ingest("H1", {"date": date(2026, 6, 1), "period": "weekly", "consumption_liters": 3500})
        reg.ingest("H1", {"date": date(2026, 6, 8), "period": "daily", "consumption_liters": 500})
        cs = MonitoringReport(reg.get_location("H1")).consumption_summary()
        self.assertEqual(cs.days_covered, 8)
        self.assertAlmostEqual(cs.avg_daily_liters, 500.0)

    def test_what_if(self):
        reg = make_registry()
        feed(reg, "H1", [(1000, 7.2, 0.5)] * 10)
        rep = MonitoringReport(reg.get_location("H1"))
        r = WhatIfAnalyzer().simulate(rep, 20)
        self.assertAlmostEqual(r.saved_daily, 200)
        self.assertAlmostEqual(r.saved_annual, 73000)
        self.assertFalse(r.meets_benchmark)           # 250 L/p/d -> 200 L/p/d, benchmark 135
        self.assertAlmostEqual(r.reduction_needed_for_benchmark_pct, 46.0, places=0)
        with self.assertRaises(ValueError):
            WhatIfAnalyzer().simulate(rep, 150)


class TestSampleScenarios(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reg = build_sample_registry()
        cls.reports = {r.location.location_id: r for r in cls.reg.build_reports()}

    def types(self, lid, pattern=None):
        return {a.alert_type for a in self.reports[lid].alerts() if pattern is None or a.pattern is pattern}

    def test_incomplete_invalid_duplicate_zero(self):
        dq = self.reports["HH-001"].data_quality()
        self.assertEqual((dq.partial, dq.rejected), (2, 2))

    def test_excessive_consumption(self):
        self.assertIn(AlertType.EXCESSIVE_CONSUMPTION, self.types("HH-002", Pattern.SUSTAINED))

    def test_abnormal_quality(self):
        self.assertIn(AlertType.HIGH_TURBIDITY, self.types("SCH-101", Pattern.SUSTAINED))
        self.assertIn(AlertType.PH_OUT_OF_RANGE, self.types("SCH-101", Pattern.ISOLATED))
        self.assertIn(AlertType.PH_ERRATIC, self.types("CC-201"))

    def test_rankings_and_conservation_exemplar(self):
        eng = RankingEngine(list(self.reports.values()))
        self.assertEqual(eng.by_conservation_priority()[0].location_id, "HH-002")
        self.assertEqual(eng.by_conservation_priority()[-1].location_id, "HH-003")
        self.assertEqual(self.reports["HH-003"].trend().direction, TrendDirection.DECREASING)


if __name__ == "__main__":
    unittest.main()
